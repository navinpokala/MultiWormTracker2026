function matched_control_BinData_array = BinData_array_date_matched_controls(experimental_BinData_array, control_BinData_array)

% date_expression = '(?<month>\d+)_(?<day>\d+)_(?<year>\d+)';
% name_words = split(experimental_BinData_array(i).Name,'.');
% find_dates_out = regexp(name_words, date_expression);

matched_control_BinData_array = []; ctrl_indicies = 1:length(experimental_BinData_array); num_missing_ctrl = 0;
for(i=1:length(experimental_BinData_array))
    name_words = split(experimental_BinData_array(i).Name,'.');
    date_string = name_words{3}; strain_string = name_words{1};
   
    j=1;
    while(j<=length(control_BinData_array))
        name_words = split(control_BinData_array(j).Name,'.');
        ctrl_date_string = name_words{3};

        if(strcmp(date_string, ctrl_date_string))
            ctrl_indicies(j) = 0;
            matched_control_BinData_array = [matched_control_BinData_array control_BinData_array(j)];
            j = 1000000;
        end
        j=j+1;
    end

    if(j<1000000)
        num_missing_ctrl = num_missing_ctrl+1;
%        disp(sprintf('%s missing control %s', strain_string, date_string))
    end
end

j=1;
while(j<=num_missing_ctrl)
    idx = find(ctrl_indicies>0);  idx=idx(1); ctrl_indicies(idx) = 0;
    matched_control_BinData_array = [matched_control_BinData_array control_BinData_array(idx)];
            name_words = split(control_BinData_array(idx).Name,'.');
        ctrl_date_string = name_words{3};
%    disp(sprintf('%s sub missing control %s', strain_string, ctrl_date_string))
    j=j+1;
end

return;
end
