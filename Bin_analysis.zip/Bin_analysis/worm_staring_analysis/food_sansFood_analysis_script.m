    global Prefs;
    Prefs = define_preferences(Prefs);
    
    
    %% join food and sansFood for all
    % for(i=0:15)
    %     join_food_sansFood_staring_BinData(sprintf('%d',i));
    % end
    
    
    % load data
    if(isempty(all_ctrl))
    matched_control_BinData = []; experimental_BinData = [];
    cmap = turbo; 
    colorstep = floor(size(cmap,1)/15); 
    all_ctrl = load_BinData_arrays('0.BinData_array.mat');
    all_control_BinData = mean_BinData_from_BinData_array(all_ctrl, sprintf('ctrl.%d',i));
    for(i=1:15)
        groupname{i} = sprintf('%d',i);
        color(i,:) = cmap(colorstep*i,:); 
    
        experimental_BinData_array = load_BinData_arrays(sprintf('%d.BinData_array.mat',i)); % load_BinData_arrays(sprintf('%d%s%d.BinData_array.mat',i,filesep,i));
        matched_control_BinData_array = BinData_array_date_matched_controls(experimental_BinData_array, all_ctrl);
    
        experimental_BinData = [experimental_BinData mean_BinData_from_BinData_array(experimental_BinData_array, sprintf('%d',i))];
        matched_control_BinData = [matched_control_BinData mean_BinData_from_BinData_array(matched_control_BinData_array, sprintf('ctrl.%d',i))];
    end
    end
    
bd = [all_control_BinData experimental_BinData]; bd(1).num_movies = 6;
comparison_plot(bd, 'stare');
comparison_plot(bd, 'stare',{'RevOmega_freq'})
compare_traces(bd,[],{'speed','RevOmega_freq'})


    % plot time-course
    attribute = 'speed';
    final_ymax=[];
    plot_rows =1; plot_columns= 1; xmin = -600; xmax = 3600; ymin =0; ymax = 1; xlabelstring = 'time (sec)'; ylabelstring = fix_title_string(attribute); 
    panel_number=1;
    for(i=1:15)
        figure(100);
        [ymin_line, ymax_line, ymin_bar, ymax_bar] = plot_attribute(experimental_BinData(i), [], plot_rows, plot_columns, xmin, xmax, ymin, ymax, xlabelstring, ylabelstring, attribute, color(i,:), panel_number);
        final_ymax = [final_ymax ymax_line ymax_bar];
        hold on;
    end
    [ymin_line, ymax_line, ymin_bar, ymax_bar] = plot_attribute(all_control_BinData, [], plot_rows, plot_columns, xmin, xmax, ymin, ymax, xlabelstring, ylabelstring, attribute, 'k', panel_number);
    plot(all_control_BinData.freqtime,all_control_BinData.(attribute),'color','k','LineWidth',4); 
    final_ymax = [final_ymax ymax_line ymax_bar];
    ylim([0 custom_round(max(final_ymax),0.5)]); 
    hold off;    
    

 % plot bargraph  
  %  time_window_mins = [5 15]; t1 = time_window_mins(1)*60; t2 = time_window_mins(2)*60; % convert to secs
    t1 = -600; t2= 0;
       for(i=1:15) 
        [experi_mean, experi_std, experi_err, experi_n] = segment_statistics(experimental_BinData(i), attribute, 'mean', t1, t2);
        [ctrl_mean, ctrl_std, ctrl_err, ctrl_n] = segment_statistics(matched_control_BinData(i), attribute, 'mean', t1, t2);
    
        p(i) = ttest_compare(experi_mean, experi_std, experi_n, ctrl_mean, ctrl_std, ctrl_n);
    
        ctrl_normalized_mean = experi_mean/ctrl_mean;
        barvalues(i) = log2(ctrl_normalized_mean); 
        barerrors(i) = ((ctrl_normalized_mean)*sqrt((experi_err/experi_mean)^2 + (ctrl_err/ctrl_mean)^2));
        barerrors(i) = barerrors(i)/(ctrl_normalized_mean*log(2));
    end
    
    p
    p<0.05/15
  
    bw_title = sprintf('%s %d %d',attribute, t1, t2);
    bw_xlabel = '';
    bw_ylabel = sprintf('log2 (%s strain/OP50)', attribute);
    bw_legend=[];
    figure(200);
    barhandles = barweb(barvalues, barerrors, 1, groupname, bw_title, bw_xlabel, bw_ylabel, color, bw_legend);
    ylim([-1.5 1.5])
    
    barvalues
    
    % -10 to 0 (food)
    
    
    % 5-10
    
    % 10-15
    
    % 15-20
    
    % 0-20
    
      % [h, crit_p] = fdr_bh(p, 0.05)
    
    function x = staring_bargraph_colormap()
    
    x = [0.7 0.7 0.7; ...   % food   gray
        0 0 1; ...          % 0-5min blue
        0 1 1; ...          % 5-10   cyan
        0 0.5 0; ...        % 10-15  dark green
        0.5 0.5 0; ...          % 15-20  yellow
        1 0 1; ...    % 20-30  magenta
        1 0 0; ];    % 30-60  red
    
    
    return;
    end
