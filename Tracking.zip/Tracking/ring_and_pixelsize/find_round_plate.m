function [radius, xc, yc] = find_round_plate(bkgnd)

global Prefs;

pixel_dim = size(bkgnd);

rel_res = NaN;

% find the largest object

% % default_threshold from pixel intensity distribution ... find rarest
% intensity higher than median

[hist_freq, pix_intens] = hist(matrix_to_vector(bkgnd),100);
median_pix = median(matrix_to_vector(bkgnd));
median_idx = find(pix_intens >= median_pix); median_idx = median_idx(1);
i = median_idx;
while(hist_freq(i) > 0.01*length(matrix_to_vector(bkgnd)))
    i=i+1;
end
default_threshold = pix_intens(i-1)/255;

% figure(100);
% histogram(matrix_to_vector(bkgnd)./255,100);
% title(sprintf('%f %f %f',mean(matrix_to_vector(bkgnd))/255, median(matrix_to_vector(bkgnd))/255, default_threshold));


RINGSTATS = custom_regionprops(bwconncomp_sorted(~im2bw(bkgnd, default_threshold), 'descend'), {'Area','Image','BoundingBox'});
RINGSTATS = RINGSTATS(1);

% get outer edges

B = bwboundaries(RINGSTATS.Image); %obtain boundary coordinates for selected objects and put into cell B
B = B{1};

% remove edge points on image edges

plate_edge_x = B(:,2);
plate_edge_y = B(:,1);

idx = find(pixel_dim(2) - plate_edge_y <=2);
plate_edge_y(idx)=[]; plate_edge_x(idx)=[];

idx = find(pixel_dim(1) - plate_edge_x <=2);
plate_edge_y(idx)=[]; plate_edge_x(idx)=[];

idx = find(plate_edge_x <=2);
plate_edge_y(idx)=[]; plate_edge_x(idx)=[];

idx = find(plate_edge_y <=2);
plate_edge_y(idx)=[]; plate_edge_x(idx)=[];

% fit to circle, get center and radius

[radius, xc,yc, rel_res] = circle_from_coords(plate_edge_x, plate_edge_y);
[x_circle,y_circle] = coords_from_circle_params(radius, [xc,yc]);

% if poor fit to circle, might be because of some clear, light area at
% lid/plate junction making an internal spur
% remove plate_edge points inside the fitted circle and try fitting again
iter = 0;
while(rel_res > 0.5 || isnan(rel_res) && iter < 2)

    IN = inpolygon(plate_edge_x,plate_edge_y,x_circle,y_circle);

    plate_edge_x(IN) = [];
    plate_edge_y(IN) = [];

    [radius, xc,yc, rel_res] = circle_from_coords(plate_edge_x, plate_edge_y);
    [x_circle, y_circle] = coords_from_circle_params(radius, [xc,yc]);

    iter = iter+1;
    
end

if(rel_res > 0.25 || isnan(rel_res) || iter>2)


    RINGSTATS = custom_regionprops(bwconncomp_sorted(~im2bw(bkgnd, manual_thresh(bkgnd)/255), 'descend'), {'Area','Image','BoundingBox'});
    RINGSTATS = RINGSTATS(1);

    % get outer edges

    B = bwboundaries(RINGSTATS.Image); %obtain boundary coordinates for selected objects and put into cell B
    B = B{1};

    % remove edge points on image edges

    plate_edge_x = B(:,2);
    plate_edge_y = B(:,1);

    idx = find(pixel_dim(2) - plate_edge_y <=2);
    plate_edge_y(idx)=[]; plate_edge_x(idx)=[];

    idx = find(pixel_dim(1) - plate_edge_x <=2);
    plate_edge_y(idx)=[]; plate_edge_x(idx)=[];

    idx = find(plate_edge_x <=2);
    plate_edge_y(idx)=[]; plate_edge_x(idx)=[];

    idx = find(plate_edge_y <=2);
    plate_edge_y(idx)=[]; plate_edge_x(idx)=[];

    % fit to circle, get center and radius

    [radius, xc,yc, rel_res] = circle_from_coords(plate_edge_x, plate_edge_y);
    [x_circle,y_circle] = coords_from_circle_params(radius, [xc,yc]);

    [~, radius, xc, yc] = circle_edge_check(bkgnd, [x_circle' y_circle']);
end

return;
end
