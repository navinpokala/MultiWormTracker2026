function LED_on(channel, current)

define_led_prefs();

if(nargin==0)
    channel = 1;
    current = 1000;
end

if(nargin==1)
    current = 1000;
end

LED_control(channel, current);

disp(['Press any key to end.'])
pause

LED_control(0);

return;

