function [radius, xc,yc, relative_residuals] = circle_from_coords(x,y)

% adapted from https://www.mathworks.com/help/images/finding-the-length-of-a-pendulum-in-motion.html
% Rewrite basic equation for a circle:
% (x-xc)^2 + (y-yc)^2 = radius^2,  where (xc,yc) is the center
% 
% in terms of parameters a, b, c as
% 
% x^2 + y^2 + a*x + b*y + c = 0,  where a = -2*xc, b = -2*yc, and
%                                       c = xc^2 + yc^2 - radius^2
% 
% [x y 1] * [a;b;c] = -x^2 - y^2.
% Solve for parameters a, b, and c in the least-squares sense by using the backslash operator
abc = [x y ones(length(x),1)] \ -(x.^2+y.^2);
a = abc(1); b = abc(2); c = abc(3);

% calculate the location of the center and the radius
xc = -a/2;
yc = -b/2;
radius  = sqrt((xc^2+yc^2)-c);

radius = double(radius);
xc = double(xc);
yc = double(yc);

% calc relative_residuals if needed
if(nargout>3)
    residuals = -(x.^2+y.^2) - [x y ones(length(x),1)]*abc;
    relative_residuals = norm(residuals) / norm(abc);
end

return;
end
