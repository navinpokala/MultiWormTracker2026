function compress_all_avi_files_in_directory

uncompressed_avi = ls_rm_ext_dirlist('ls', pwd, '-0000.avi');

for(i=1:length(uncompressed_avi))
    [status, result] = force_avi_file_to_defined_time_and_compress_mpeg(uncompressed_avi{i});
    disp([status, result])
end
