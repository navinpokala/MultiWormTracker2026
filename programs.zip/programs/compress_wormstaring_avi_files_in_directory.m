function compress_wormstaring_avi_files_in_directory

uncompressed_avi = ls_rm_ext_dirlist('ls', pwd, '-0000.avi');

for(i=1:length(uncompressed_avi))

    compressed_filename = erase(uncompressed_avi{i},'-0000');

    disp([uncompressed_avi{i}, compressed_filename])

    if((strfind(uncompressed_avi{i},'.food'))) % food
        [status, result] = force_avi_file_to_defined_time_and_compress_mpeg(uncompressed_avi{i}, compressed_filename,900);
    else
        if((strfind(uncompressed_avi{i},'.sansFood')))
            [status, result] = force_avi_file_to_defined_time_and_compress_mpeg(uncompressed_avi{i}, compressed_filename,3600);
        end
    end

    disp([status, result])

end
