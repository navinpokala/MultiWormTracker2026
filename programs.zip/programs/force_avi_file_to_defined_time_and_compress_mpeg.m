function [status, result] = force_avi_file_to_defined_time_and_compress_mpeg(filename, output_avi_filename, duration_sec, framerate)
% [status, result] = force_avi_file_to_defined_time_and_compress_mpeg(filename, outputfilename, duration_sec, framerate)


if(nargin==0)
    disp(['Usage: [status, result] = force_avi_file_to_defined_time_and_compress_mpeg(filename, outputfilename, duration_sec, framerate)'])
    disp(['Forces an avi file to be duration_sec seconds long'])
    disp(['framerate is optional; defaults to 3 frames per second'])
    return
end

if(nargin<4)
    framerate=3;
end

if(nargin<3)
    fileinfo = dir(filename);
    movie_info = moviefile_info(filename);
    duration_sec = (round(fileinfo.bytes/(3*movie_info.Height*movie_info.Width)))/framerate; % 1228800 = 3*640*640
end

if(nargin<2)
    output_avi_filename = erase(filename,'-0000');
end

numframes = duration_sec*framerate;

command = sprintf('ffmpeg -i %s -frames:v %d -r %d -c:v mpeg4 %s',filename,  numframes, framerate, output_avi_filename);
disp(command)
[status, result] = system(command);

return;
end
