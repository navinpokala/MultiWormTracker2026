function overlay_microtiter_plate(Plate, plotting_matrix, plot_title)

if(nargin<1)
    disp('usage: overlay_microtiter_plate(Plate, plotting_matrix, plot_title (optional)')
    return;
end

% plotting_matrix
% plate_index_1  row_number_1  color_1
% plate_index_2  row_number_2  color_2
% plate_index_3  row_number_3  color_3
% plate_index_4  row_number_4  color_4

% Plate(i).plate_matrix
% Plate(i).row_labels
% Plate(i).initial_concs

if(nargin < 3)
    plot_title = '';
end

all_val = [];
for(i=1:length(Plate))
    all_val = [all_val Plate(i).plate_matrix];
    if(length(Plate(i).initial_concs)==1)
        x = Plate(i).initial_concs;
        Plate(i).initial_concs = zeros(length(Plate(i).row_labels));
        for(j=1:length(Plate(i).row_labels))
            Plate(i).initial_concs(j)=x;
        end
    end
    max_signal = max(max(max(max(max(all_val)))));
    
    
    for(k=1:size(plotting_matrix,1))
        plate_idx = plotting_matrix{k,1};
        row_idx = plotting_matrix{k,2};
        
        xvals = Plate(plate_idx).initial_concs(row_idx)*2.^-([0:1:(length(Plate(plate_idx).plate_matrix(row_idx,:))-1)]);
        
        plot(xvals, Plate(plate_idx).plate_matrix(row_idx,:), 'marker', '.', 'color', str2rgb(plotting_matrix{k,3}),'markersize',32);
        
        legend_text{k} = Plate(plate_idx).row_labels{row_idx};
        legend_colors{k} = plotting_matrix{k,3};
        
        hold on;
    end
    
    ylabel('A620');
    ylim([0 max_signal]);
    ax = gca; ax.XAxis.Scale = 'log';
    box off
    if(~isempty(plot_title))
        title(plot_title);
    end
    set_axes_fontstuff(gca,'fontsize',18);
    legend(legend_text);
    
    
    
end


