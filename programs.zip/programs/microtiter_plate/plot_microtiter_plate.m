function plot_microtiter_plate(plate_matrix, row_labels, initial_concs)

if(nargin<1)
    disp('usage: plot_microtiter_plate(plate_matrix, row_labels, initial_concs');
    return;
end

if(nargin<3)
    initial_concs = 1;
end


if(length(initial_concs)==1)
   x = initial_concs;
   initial_concs = zeros(length(row_labels));
   for(i=1:length(row_labels))
       initial_concs(i)=x;
   end
end

for(i=1:length(row_labels))
    Row(i).Label = 	row_labels{i};
    Row(i).conc = 	initial_concs(i);
    Row(i).dose_response = plate_matrix(i,:);
end


max_signal = max(max(plate_matrix));

fignum = 1;
a = gcf;
if(a.Number>1)
    fignum = a.Number+1;
end

figure(fignum);
for(i=1:length(Row))
    subplot(2,4,i);    set(gcf,'color','w');
    plot_row_dose_response(Row(i), max_signal);
end


% heatmap
figure(fignum+1);
H = [];
for(i=1:length(Row))
%   H = [H;  Row(i).dose_response./max(Row(i).dose_response)];
   H = [H;  Row(i).dose_response./max_signal];
end
heatmap(H, [0:-1:-(length(Row(1).dose_response)-1)], row_labels);
xlabel(sprintf('log2 dil. factor'));
colormap(jet);
set_axes_fontstuff(gca,'fontsize',18);
set(gcf,'color','w'); 



end

function plot_row_dose_response(Row, max_signal)

drug = Row.conc*2.^-([0:1:(length(Row.dose_response)-1)]);

plot(drug, Row.dose_response, '.-b','markersize',24);
ylabel('A600');
% ylim([0 max(max(Row.dose_response))]);
ylim([0 max_signal]);

ax = gca; ax.XAxis.Scale = 'log';

title(sprintf('%s',Row.Label));

box off
set_axes_fontstuff(gca,'fontsize',18);

end

